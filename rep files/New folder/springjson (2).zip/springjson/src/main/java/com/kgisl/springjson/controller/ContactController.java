package com.kgisl.springjson.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kgisl.springjson.dao.ContactDAO;
import com.kgisl.springjson.model.Contact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 * ContactController
 */
@RestController
@RequestMapping("/contacts")
public class ContactController {

    @Autowired
    private ContactDAO contactDAO;

    @RequestMapping(value = "/getAll")
    public List<Contact> getAll() {
        List<Contact> listContact = contactDAO.list();
        // model.addAttribute("listContact", listContact);
        return listContact;
    }

    @RequestMapping(value = "/new", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String newContact(HttpEntity<String> httpEntity)
            throws JsonParseException, JsonMappingException, IOException {
        String json = httpEntity.getBody();
        System.out.println(json);
        ObjectMapper mapper = new ObjectMapper();
        // JSON string to Java Object
        Contact newContact = mapper.readValue(json, Contact.class);
        System.out.println(newContact);
        contactDAO.saveOrUpdate(newContact);
        return "model";
    }

    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ModelAndView deleteContact(HttpServletRequest request) {
        int contactId = Integer.parseInt(request.getParameter("id"));
        contactDAO.delete(contactId);
        return new ModelAndView("redirect:/");
    }

}
