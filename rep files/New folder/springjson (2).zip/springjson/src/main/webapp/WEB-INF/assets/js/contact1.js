var app = new function () {
    this.employees=[];
    this.getAllEmployees = function () {
        alert();

    };
    this.add = function () {
        // {"name":"test","salary":"123","age":"23"}

        var data = {};
        data.name = document.getElementById("name").value;
        data.salary = document.getElementById("salary").value;
        data.age = document.getElementById("age").value;
        var json = JSON.stringify(data);
        alert(json);
        console.log(json);

        // Post a user
        var xhttp = new XMLHttpRequest();
        xhttp.open("POST", "http://dummy.restapiexample.com/api/v1/create", true);
        xhttp.send(json);
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                // Typical action to be performed when the document is ready:
                // document.getElementById("demo").innerHTML = xhttp.responseText;
            }
        };

    };
}