
var app = new function () {
    var countries = [];
    var result;
    var mode = "";
    this.FetchAll = function () {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == XMLHttpRequest.DONE) {

                result = xhr.responseText;

                countries = JSON.parse(result);

                app.printtable();
            }
        }
        xhr.open('GET', 'http://localhost:9090/contacts/getAll', true);
        xhr.send(null);
    };




    this.printtable = function () {
        var object = JSON.parse(result);
        this.el = document.getElementById("countries");
        var data = '';
        for (var i in object) {
            data += '<tr>';
            data += '<td>' + object[i].id + '</td>';
            data += '<td>' + object[i].name + '</td>';
            data += '<td>' + object[i].email + '</td>';
            data += '<td>' + object[i].address + '</td>';
            data += '<td>' + object[i].telephone + '</td>';
            data += '<td><button onclick="app.Edit(' + object[i].id + ')">Edit</button></td>';
            data += '<td><button onclick="app.Delete(' + object[i].id + ')">Delete</button></td>';
            data += '</tr>';
            data += '<br>';
            data += '<br>';
        }
        this.el.innerHTML = data;
    };


    this.Edit = function (id) {
        mode = "edit";
        document.getElementById('btn').innerHTML = "Update";
        for (var i = 0; i < countries.length; i++) {
            if (countries[i].id == id) {

                document.getElementById('id').value = countries[i].id;
                document.getElementById('name').value = countries[i].name;
                document.getElementById('email').value = countries[i].email;
                document.getElementById('address').value = countries[i].address;
                document.getElementById('telephone').value = countries[i].telephone;
            }
        }
    };


    this.saveorupdate = function () {
        var id = document.getElementById('id').value;
        var name = document.getElementById('name').value;
        if (mode == "") {
            alert("save called");
            alert("id" + id + "name  " + name);

            var url = "http://localhost:9090/contacts/new";
            var xhr = new XMLHttpRequest();
            var data = {};
            data.name = document.getElementById("name").value;
            data.email = document.getElementById("email").value;
            data.address = document.getElementById("address").value;
            data.telephone = document.getElementById("telephone").value;
            var json = JSON.stringify(data);
            xhr.onload = function () {
                if (xhr.readyState == 4 && xhr.status == "200") {
                    app.FetchAll();
                }
            }
            xhr.open("POST", url , true);
            xhr.setRequestHeader('Content-type','application/json; charset=utf-8');
            xhr.send(json);

            app.FetchAll();
        }
        else {
            alert("update called");
            alert("id" + id + "name  " + name);

            var url = "http://localhost:9090/contacts/new";
            var xhr = new XMLHttpRequest();
            var data = {};
            data.id = document.getElementById("id").value;
            data.name = document.getElementById("name").value;
            data.email = document.getElementById("email").value;
            data.address = document.getElementById("address").value;
            data.telephone = document.getElementById("telephone").value;
            var json = JSON.stringify(data);
            xhr.onload = function () {
                if (xhr.readyState == 4 && xhr.status == "200") {
                    app.FetchAll();
                }
            }
            xhr.open("POST", url , true);
            xhr.setRequestHeader('Content-type','application/json; charset=utf-8');
            xhr.send(json);
            document.getElementById('btn').innerHTML = "Add";
            mode = "";
            app.FetchAll();
        }

        document.getElementById('id').value = "";
        document.getElementById('name').value = "";
        document.getElementById('email').value = "";
        document.getElementById('address').value = "";
        document.getElementById('telephone').value = "";
    };




    this.Delete = function (id) {
        console.log("delete called " + id);
        var url = 'http://localhost:9090/contacts/delete';
        var xhr = new XMLHttpRequest();
        // var id = document.getElementById("id").value;
        xhr.open("GET", url + '?id=' + id, true);
        xhr.onload = function () {
            if (xhr.readyState == 4 && xhr.status == "200") {
                app.FetchAll();
            }
        }
        xhr.send(null);
        app.FetchAll();
    };
}

